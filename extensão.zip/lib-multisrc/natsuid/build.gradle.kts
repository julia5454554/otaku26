plugins {
    alias(kei.plugins.multisrc)
}

keiyoushi {
    baseVersionCode = 6
    libVersion = "1.6"

    deeplink {
        path("/manga/..*")
    }
}
