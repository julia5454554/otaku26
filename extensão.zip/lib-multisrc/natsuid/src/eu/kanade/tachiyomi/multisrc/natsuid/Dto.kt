package eu.kanade.tachiyomi.multisrc.natsuid

import eu.kanade.tachiyomi.source.model.SManga
import keiyoushi.utils.toJsonString
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonNames
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.jsoup.Jsoup
import org.jsoup.parser.Parser

@Serializable
class Term(
    val name: String,
    val slug: String,
    val taxonomy: String,
)

@Serializable
class Manga(
    val id: Int,
    val slug: String,
    val title: Rendered,
    val content: Rendered,
    @JsonNames("metadata")
    val meta: MangaMeta? = null,
    @SerialName("_embedded")
    val embedded: Embedded,
) {
    val isNovel get() = embedded.getTerms("type").contains("Novel")

    fun toSManga() = SManga.create().apply {
        url = MangaUrl(id, slug).toJsonString()
        title = Parser.unescapeEntities(this@Manga.title.rendered, false)
        val mainDescription = Jsoup.parseBodyFragment(content.rendered).wholeText().trim()
        // The alternative_title field is comma-separated on the site
        val altTitles = meta?.meta?.alternativeTitle
            ?.split(",")
            ?.map { Parser.unescapeEntities(it.trim(), false) }
            ?.filter { it.isNotBlank() && !it.equals(title, ignoreCase = true) }
            ?.distinct()
            .orEmpty()

        description = buildString {
            append(mainDescription)
            if (altTitles.isNotEmpty()) {
                if (isNotEmpty()) append("\n\n")
                append("Alternative Names:\n")
                append(altTitles.joinToString("\n") { "- $it" })
            }
        }.trim()
        thumbnail_url = embedded.featuredMedia?.firstOrNull()?.sourceUrl
        author = embedded.getTerms("series-author").joinToString()
        artist = embedded.getTerms("artist").joinToString()
        genre = buildSet {
            addAll(embedded.getTerms("genre"))
            addAll(embedded.getTerms("type"))
        }.joinToString()
        status = with(embedded.getTerms("status")) {
            when {
                contains("Ongoing") -> SManga.ONGOING
                contains("Completed") -> SManga.COMPLETED
                contains("Cancelled") -> SManga.CANCELLED
                contains("On Hiatus") -> SManga.ON_HIATUS
                else -> SManga.UNKNOWN
            }
        }
        memo = buildJsonObject {
            put("id", id)
        }
        initialized = true
    }
}

@Serializable
class MangaMeta(
    val meta: InnerMeta? = null,
)

@Serializable
class InnerMeta(
    @SerialName("alternative_title")
    val alternativeTitle: String? = null,
)

@Serializable
class Embedded(
    @SerialName("wp:featuredmedia")
    val featuredMedia: List<FeaturedMedia>?,
    @SerialName("wp:term")
    private val terms: List<List<Term>>,
) {
    fun getTerms(type: String): List<String> = terms.find { it.getOrNull(0)?.taxonomy == type }?.map { it.name } ?: emptyList()
}

@Serializable
class FeaturedMedia(
    @SerialName("source_url")
    val sourceUrl: String,
)

@Serializable
class Rendered(
    val rendered: String,
)

@Serializable
class MangaUrl(
    val id: Int,
    val slug: String,
)
