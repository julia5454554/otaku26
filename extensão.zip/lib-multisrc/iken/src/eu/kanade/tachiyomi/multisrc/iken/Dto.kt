package eu.kanade.tachiyomi.multisrc.iken

import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.jsoup.Jsoup
import kotlin.time.Instant

@Serializable
class SearchResponse(
    val posts: List<Manga>,
    val totalCount: Int,
)

@Serializable
class MangaDto(
    val totalChapterCount: Int? = null,
    val post: Manga,
)

@Serializable
class ChapterDto(
    val post: ChapterPost,
)

@Serializable
class ChapterPost(
    val chapters: List<Chapter>,
)

@Serializable
class PageResponse(
    val chapter: Page,
)

@Serializable
class ViewQuery(
    val postId: Int?,
    val chapterId: Int?,
)

@Serializable
class RelatedMangaDto(
    val recommendations: List<Manga>,
)

@Serializable
class Manga(
    val id: Int,
    val slug: String,
    private val postTitle: String,
    private val postContent: String? = null,
    @SerialName("isNovel")
    private val rawIsNovel: Boolean = false,
    private val featuredImage: String? = null,
    private val alternativeTitles: String? = null,
    private val author: String? = null,
    private val artist: String? = null,
    private val seriesType: String? = null,
    private val seriesStatus: String? = null,
    private val genres: List<Genre> = emptyList(),
    val chapters: List<Chapter> = emptyList(),
) {

    val isNovel: Boolean
        get() = rawIsNovel || seriesType.equals("novel", ignoreCase = true)

    fun toSManga() = SManga.create().apply {
        url = "$slug#$id"
        title = postTitle
        thumbnail_url = featuredImage
        author = this@Manga.author?.takeUnless { it.isEmpty() }
        artist = this@Manga.artist?.takeUnless { it.isEmpty() }
        description = getDescription(postContent)
        genre = getGenres()
        status = getStatus()
        memo = buildJsonObject {
            put("id", id)
            put("slug", slug)
        }
    }

    fun getDescription(postContent: String?) = buildString {
        postContent?.takeUnless { it.isEmpty() }?.let { desc ->
            append(Jsoup.parse(desc.replace("\n", "<br>")).text())
        }
        alternativeTitles?.takeUnless { it.isEmpty() }?.let { altName ->
            append("\n\n")
            append("Alternative Names: ")
            append(altName)
        }
    }.trim()

    private fun getStatus() = when (seriesStatus) {
        "ONGOING", "COMING_SOON", "MASS_RELEASED" -> SManga.ONGOING
        "COMPLETED" -> SManga.COMPLETED
        "CANCELLED", "DROPPED" -> SManga.CANCELLED
        else -> SManga.UNKNOWN
    }

    private fun getGenres() = buildList {
        when (seriesType) {
            "MANGA" -> add("Manga")
            "MANHUA" -> add("Manhua")
            "MANHWA" -> add("Manhwa")
            else -> {}
        }
        genres.forEach { add(it.name) }
    }.distinct().joinToString()
}

@Serializable
class Genre(
    val id: Int,
    val name: String,
)

@Serializable
class DescriptionDto(
    val description: String,
)

@Serializable
class Chapter(
    private val id: Int,
    private val slug: String,
    private val number: JsonPrimitive,
    private val title: String? = null,
    private val createdAt: String,
    private val isLocked: Boolean? = false,
    private val isTimeLocked: Boolean? = false,
    private val mangaPost: MangaPostDto? = null,
    private val price: Int? = 0,
    private val chapterPurchased: Boolean? = false,
) {

    fun isLocked() = (isLocked == true) || (isTimeLocked == true) || (chapterPurchased == false && price != 0)

    fun toSChapter(mangaSlug: String?) = SChapter.create().apply {
        val prefix = if (isLocked()) "🔒 " else ""
        val suffix = if (!title.isNullOrBlank()) " - $title" else ""
        val seriesSlug = (mangaSlug ?: mangaPost?.slug)!!
        url = "/series/$seriesSlug/$slug#$id"
        name = "${prefix}Chapter $number$suffix"
        date_upload = Instant.parseOrNull(createdAt)?.toEpochMilliseconds() ?: 0L
        memo = buildJsonObject {
            put("seriesSlug", seriesSlug)
            put("slug", slug)
            put("id", id)
        }
    }
}

@Serializable
class MangaPostDto(
    val slug: String?,
)

@Serializable
class Page(
    val images: List<PageParseDto>,
    val isPermanentlyLocked: Boolean = false,
    val isLockedByCoins: Boolean = false,
    val isShortLinkLocked: Boolean = false,
)

@Serializable
class PageParseDto(
    val url: String,
    val order: Int? = null,
)
