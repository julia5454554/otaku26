package eu.kanade.tachiyomi.multisrc.clipstudioreader

import eu.kanade.tachiyomi.source.model.Page
import keiyoushi.network.get
import keiyoushi.source.KeiSource
import keiyoushi.utils.asJsoup
import keiyoushi.utils.parseAs
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Response
import org.jsoup.nodes.Document
import org.jsoup.parser.Parser

abstract class ClipStudioReader : KeiSource() {

    override fun OkHttpClient.Builder.configureClient(): OkHttpClient.Builder = addClipStudioInterceptors()

    protected fun OkHttpClient.Builder.addClipStudioInterceptors(): OkHttpClient.Builder = addInterceptor(Deobfuscator())
        .addInterceptor(ImageInterceptor())

    protected suspend fun pageListParse(response: Response): List<Page> {
        val requestUrl = response.request.url
        val contentId = requestUrl.queryParameter("c")

        if (contentId != null) {
            // EPUB-based path
            val tokenUrl = "$baseUrl/api/tokens/viewer?content_id=$contentId"
            val viewerToken = client.get(tokenUrl).parseAs<TokenResponse>().token

            val metaUrl = "$baseUrl/api/contents/$contentId/meta"
            val apiHeaders = headersBuilder().add("Authorization", "Bearer $viewerToken").build()
            val contentBaseUrl = client.get(metaUrl, apiHeaders).parseAs<MetaResponse>().content.baseUrl

            val preprocessUrl = "$contentBaseUrl/preprocess-settings.json"
            val obfuscationKey = client.get(preprocessUrl).parseAs<PreprocessSettings>().obfuscateImageKey

            val containerUrl = "$contentBaseUrl/META-INF/container.xml"
            val containerDoc = client.get(containerUrl).asJsoup(Parser.xmlParser())
            val opfPath = containerDoc.selectFirst("*|rootfile")?.attr("full-path")
                ?: throw Exception("Failed to find rootfile in container.xml")

            val opfUrl = (contentBaseUrl.removeSuffix("/") + "/" + opfPath).toHttpUrl()
            val opfDoc = client.get(opfUrl).asJsoup()

            val imageManifestItems = opfDoc.select("*|item[media-type^=image/]")
                .sortedBy { it.attr("href") }
            if (imageManifestItems.isEmpty()) {
                throw Exception("No image pages found in the EPUB manifest")
            }

            return imageManifestItems.mapIndexed { i, item ->
                val href = item.attr("href")
                val imageUrl = opfUrl.resolve(href)!!.newBuilder()
                    .fragment("key=$obfuscationKey")
                Page(i, imageUrl = imageUrl.build().toString())
            }
        }

        // param/cgi-based XML path
        // param/cgi in URL
        var authkey = requestUrl.queryParameter("param")?.replace(" ", "+")
        var endpoint = requestUrl.queryParameter("cgi")

        // param/cgi in HTML
        if (authkey.isNullOrEmpty() || endpoint.isNullOrEmpty()) {
            val document = response.asJsoup()
            authkey = document.selectFirst("div#meta input[name=param]")?.attr("value")
                ?: throw Exception("Could not find auth key")
            endpoint = document.selectFirst("div#meta input[name=cgi]")?.attr("value")
                ?: throw Exception("Could not find endpoint")
        }

        val viewerUrl = baseUrl.toHttpUrl().resolve(endpoint)
            ?: throw Exception("Could not resolve endpoint URL: $endpoint")

        val faceUrl = viewerUrl.newBuilder().apply {
            addQueryParameter("mode", MODE_DL_FACE_XML)
            addQueryParameter("reqtype", REQUEST_TYPE_FILE)
            addQueryParameter("vm", "4")
            addQueryParameter("file", "face.xml")
            addQueryParameter("param", authkey)
        }.build()

        val faceData = parseFaceData(client.get(faceUrl).asJsoup())

        return (0 until faceData.totalPages).map { i ->
            val pageFileName = i.toString().padStart(4, '0') + ".xml"
            val pageXmlUrl = viewerUrl.newBuilder().apply {
                addQueryParameter("mode", MODE_DL_PAGE_XML)
                addQueryParameter("reqtype", REQUEST_TYPE_FILE)
                addQueryParameter("vm", "4")
                addQueryParameter("file", pageFileName)
                addQueryParameter("param", authkey)
            }.fragment("${faceData.scrambleWidth}/${faceData.scrambleHeight}")
            Page(i, url = pageXmlUrl.build().toString())
        }
    }

    override suspend fun getImageUrl(page: Page): String {
        val response = client.get(page.url)
        val requestUrl = response.request.url
        val document = response.asJsoup()

        val authkey = requestUrl.queryParameter("param")!!
        val (scrambleGridW, scrambleGridH) = requestUrl.fragment!!.split('/')
        val endpointUrl = requestUrl.newBuilder().query(null).fragment(null).build()

        val pageIndex = document.selectFirst("PageNo")?.text()?.toIntOrNull()
            ?: throw Exception("Could not find PageNo")
        val scrambleArray = document.selectFirst("Scramble")?.text()
        val parts = document.select("Kind").mapNotNull {
            val type = it.text().toIntOrNull()
            val number = it.attr("No")
            val isScrambled = it.attr("scramble") == "1"
            if (type == null || number.isEmpty()) return@mapNotNull null

            val partFileName = "${pageIndex.toString().padStart(4, '0')}_${number.padStart(4, '0')}.bin"
            PagePart(partFileName, type, isScrambled)
        }

        val imagePart = parts.firstOrNull { it.type in SUPPORTED_IMAGE_TYPES }
            ?: throw Exception("No supported image parts found for page")

        val imageUrlBuilder = endpointUrl.newBuilder().apply {
            addQueryParameter("mode", imagePart.type.toString())
            addQueryParameter("file", imagePart.fileName)
            addQueryParameter("reqtype", REQUEST_TYPE_FILE)
            addQueryParameter("param", authkey)
        }

        if (imagePart.isScrambled && !scrambleArray.isNullOrEmpty()) {
            imageUrlBuilder.fragment("size=$scrambleArray/$scrambleGridW/$scrambleGridH")
        }
        return imageUrlBuilder.build().toString()
    }

    private fun parseFaceData(document: Document): FaceData {
        val totalPages = document.selectFirst("TotalPage")?.text()?.toIntOrNull()
        val scrambleWidth = document.selectFirst("Scramble > Width")?.text()?.toIntOrNull()
        val scrambleHeight = document.selectFirst("Scramble > Height")?.text()?.toIntOrNull()
        return FaceData(totalPages!!, scrambleWidth!!, scrambleHeight!!)
    }

    companion object {
        private const val MODE_DL_FACE_XML = "7"
        private const val MODE_DL_PAGE_XML = "8"
        private const val REQUEST_TYPE_FILE = "0"

        private val SUPPORTED_IMAGE_TYPES = setOf(1, 2, 3) // JPEG, GIF, PNG
    }
}
