import importlib.util
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


SCRIPT = Path(__file__).with_name("sync-upstream.py")
SPEC = importlib.util.spec_from_file_location("sync_upstream", SCRIPT)
sync_upstream = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(sync_upstream)


class PublishSyncTest(unittest.TestCase):
    def test_local_versions_ahead_are_not_treated_as_missing_upstream_updates(self):
        with patch.object(
            sync_upstream,
            "local_version_ahead_of_upstream",
            return_value=((3, 0, 3), (2, 0, 2)),
        ), patch.object(
            sync_upstream,
            "has_newer_upstream_for_version_only_unit",
            return_value=False,
        ):
            pending = sync_upstream.pending_sync_units(
                ["src/tr/korelimanga"], [], "upstream/main",
            )

        self.assertEqual(pending, [])

    def test_pushes_main_then_sync_without_pr_or_temporary_branch(self):
        events = []

        def fake_git(*args, check=True):
            events.append(("git", args))
            if args == ("rev-parse", "origin/main"):
                return "main-start\n"
            return ""

        def fake_update(ref, push):
            events.append(("sync", ref, push))

        with patch.object(sync_upstream, "git", side_effect=fake_git), patch.object(
            sync_upstream, "update_sync_branch", side_effect=fake_update,
        ):
            sync_upstream.publish_sync("upstream/main", "main-start")

        self.assertIn(("git", ("push", "origin", "HEAD:main")), events)
        self.assertIn(("sync", "upstream/main", True), events)
        main_index = events.index(("git", ("push", "origin", "HEAD:main")))
        sync_index = events.index(("sync", "upstream/main", True))
        self.assertLess(main_index, sync_index)
        git_args = [event[1] for event in events if event[0] == "git"]
        self.assertFalse(any("sync-update-" in " ".join(args) for args in git_args))
        self.assertFalse(any(args and args[0] == "gh" for args in git_args))

    def test_main_push_failure_is_propagated_and_sync_is_not_attempted(self):
        def fake_git(*args, check=True):
            if args == ("rev-parse", "origin/main"):
                return "main-start\n"
            if args == ("push", "origin", "HEAD:main"):
                raise SystemExit(7)
            return ""

        with patch.object(sync_upstream, "git", side_effect=fake_git), patch.object(
            sync_upstream, "update_sync_branch",
        ) as update:
            with self.assertRaises(SystemExit):
                sync_upstream.publish_sync("upstream/main", "main-start")
        update.assert_not_called()

    def test_sync_push_failure_is_propagated(self):
        def fake_git(*args, check=True):
            if args == ("rev-parse", "origin/main"):
                return "main-start\n"
            if args == ("push", "origin", "upstream/main:refs/heads/sync"):
                raise SystemExit(8)
            return ""

        with patch.object(sync_upstream, "git", side_effect=fake_git):
            with self.assertRaises(SystemExit):
                sync_upstream.publish_sync("upstream/main", "main-start")

    def test_main_push_is_normal_and_never_forced(self):
        calls = []

        def fake_git(*args, check=True):
            calls.append(args)
            if args == ("rev-parse", "origin/main"):
                return "main-start\n"
            return ""

        with patch.object(sync_upstream, "git", side_effect=fake_git), patch.object(
            sync_upstream, "update_sync_branch",
        ):
            sync_upstream.publish_sync("upstream/main", "main-start")

        main_push = next(args for args in calls if args[:2] == ("push", "origin"))
        self.assertEqual(main_push, ("push", "origin", "HEAD:main"))
        self.assertNotIn("-f", main_push)

    def test_main_advance_aborts_before_push(self):
        calls = []

        def fake_git(*args, check=True):
            calls.append(args)
            if args == ("rev-parse", "origin/main"):
                return "new-main\n"
            return ""

        with patch.object(sync_upstream, "git", side_effect=fake_git), patch.object(
            sync_upstream, "update_sync_branch",
        ) as update:
            with self.assertRaisesRegex(RuntimeError, "origin/main advanced"):
                sync_upstream.publish_sync("upstream/main", "old-main")

        self.assertFalse(any(args[:2] == ("push", "origin") for args in calls))
        update.assert_not_called()

    def test_no_upstream_changes_do_not_commit_or_push(self):
        calls = []

        def fake_git(*args, check=True):
            calls.append(args)
            if args == ("rev-parse", "origin/main"):
                return "main\n"
            if args == ("rev-parse", "HEAD"):
                return "main\n"
            return ""

        with patch.object(sync_upstream, "ensure_clean_tree"), patch.object(
            sync_upstream, "ensure_upstream_remote",
        ), patch.object(sync_upstream, "changed_entries", return_value=[]), patch.object(
            sync_upstream, "collect_units", return_value=([], []),
        ), patch.object(sync_upstream, "get_protected_nox_units", return_value=[]), patch.object(
            sync_upstream, "structural_conflicts", return_value=[],
        ), patch.object(sync_upstream, "preflight_multisrc", return_value=({}, set())), patch.object(
            sync_upstream, "protected_multisrc_bases", return_value={},
        ), patch.object(sync_upstream, "print_plan"), patch.object(
            sync_upstream, "load_deferred_migrations", return_value={},
        ), patch.object(sync_upstream, "git", side_effect=fake_git), patch.object(
            sync_upstream.subprocess, "run", return_value=SimpleNamespace(returncode=0),
        ), patch.object(sync_upstream.sys, "argv", ["sync-upstream.py"]):
            sync_upstream.main()

        self.assertFalse(any(args and args[0] == "commit" for args in calls))
        self.assertFalse(any(args and args[0] == "push" for args in calls))


class StructuralMetadataTest(unittest.TestCase):
    def apply(self, local: str, upstream: str) -> tuple[str, bool]:
        with tempfile.TemporaryDirectory() as directory:
            previous = Path.cwd()
            try:
                os.chdir(directory)
                path = Path("src/pt/example/build.gradle.kts")
                path.parent.mkdir(parents=True)
                path.write_text(local)
                with patch.object(sync_upstream, "_read_file_text", return_value=upstream):
                    changed = sync_upstream.merge_structural_metadata("src/pt/example", "upstream/main")
                return path.read_text(), changed
            finally:
                os.chdir(previous)

    def test_local_16_can_follow_proven_upstream_selector(self):
        result, changed = self.apply('versionCode = 6\nlibVersion = "1.6"\n', 'versionCode = 5\nlibVersion = "1.4"\n')
        self.assertIn('libVersion = "1.4"', result)
        self.assertTrue(changed)

    def test_blackout_selector_is_only_changed_by_proven_plan(self):
        result, changed = self.apply('versionCode = 11\nlibVersion = "1.6"\n', 'versionCode = 10\nlibVersion = "1.4"\n')
        self.assertIn('libVersion = "1.4"', result)
        self.assertTrue(changed)

    def test_local_14_migrates_to_upstream_16(self):
        result, changed = self.apply('libVersion = "1.4"\n', 'libVersion = "1.6"\n')
        self.assertIn('libVersion = "1.6"', result)
        self.assertTrue(changed)

    def test_missing_local_lib_version_accepts_upstream(self):
        result, changed = self.apply('versionCode = 1\n\nsource {\n}\n', 'libVersion = "1.6"\n')
        self.assertIn('libVersion = "1.6"', result)
        self.assertTrue(changed)

    def test_two_protected_dependents_are_persisted(self):
        report = {"theme": [{"unit": "src/pt/a", "migration_required": True}, {"unit": "src/pt/b", "migration_required": True}]}
        state = sync_upstream.deferred_state(report, {"theme"}, "upstream/a")
        self.assertEqual(state["theme"]["units"], ["src/pt/a", "src/pt/b"])

    def test_mixed_compatibility_defers_only_required_unit(self):
        report = {"theme": [{"unit": "src/pt/a", "migration_required": False}, {"unit": "src/pt/b", "migration_required": True}]}
        state = sync_upstream.deferred_state(report, {"theme"}, "upstream/a")
        self.assertEqual(state["theme"]["units"], ["src/pt/b"])

    def test_dependency_map_recalculates_theme_changes(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = Path.cwd()
            try:
                os.chdir(directory)
                for name, theme in (("a", "one"), ("b", "two")):
                    path = Path("src/pt") / name / "build.gradle.kts"
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(f'theme = "{theme}"\nlibVersion = "1.6"\n')
                self.assertEqual(sync_upstream.dependency_map(None), {"one": ["src/pt/a"], "two": ["src/pt/b"]})
            finally:
                os.chdir(previous)

    def test_base_version_change_is_monotonic(self):
        with tempfile.TemporaryDirectory() as directory:
            previous_dir = Path.cwd()
            try:
                os.chdir(directory)
                extension = Path("src/pt/a/build.gradle.kts")
                extension.parent.mkdir(parents=True)
                extension.write_text('versionCode = 2\ntheme = "x"\nlibVersion = "1.6"\n')
                multisrc = Path("lib-multisrc/x/build.gradle.kts")
                multisrc.parent.mkdir(parents=True)
                multisrc.write_text('baseVersionCode = 14\nlibVersion = "1.6"\n')
                old = sync_upstream.effective_version_code(None, "src/pt/a")
                multisrc.write_text('baseVersionCode = 16\nlibVersion = "1.6"\n')
                sync_upstream.bump_after_structural_change("src/pt/a", old)
                self.assertGreater(sync_upstream.effective_version_code(None, "src/pt/a")[2], old[2])
            finally:
                os.chdir(previous_dir)

    def test_deferred_reappears_and_then_resolves(self):
        report = {"theme": [{"unit": "src/pt/a", "migration_required": True}]}
        self.assertIn("theme", sync_upstream.deferred_state(report, {"theme"}, "upstream/one"))
        self.assertIn("theme", sync_upstream.deferred_state(report, {"theme"}, "upstream/two"))
        self.assertEqual(sync_upstream.deferred_state({"theme": []}, set(), "upstream/three"), {})

    def test_github_paths_and_source_are_preserved(self):
        self.assertIsNone(sync_upstream.sync_unit(".github/workflows/sync_upstream.yml"))
        result, _ = self.apply('libVersion = "1.4"\nsource {\n baseUrl = "https://nox"\n}\n', 'libVersion = "1.6"\n')
        self.assertIn("https://nox", result)

    def test_unrelated_unit_is_absent_from_deferred_backlog(self):
        state = sync_upstream.deferred_state({"theme": [{"unit": "src/pt/a", "migration_required": True}]}, {"theme"}, "up")
        self.assertNotIn("src/pt/unrelated", str(state))

    def test_missing_multisrc_is_not_compatible(self):
        self.assertIsNone(sync_upstream.multisrc_metadata(None, "does-not-exist"))

    def test_effective_version_includes_base_version(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = Path.cwd()
            try:
                os.chdir(directory)
                path = Path("src/pt/a/build.gradle.kts"); path.parent.mkdir(parents=True)
                path.write_text('versionCode = 2\ntheme = "x"\nlibVersion = "1.6"\n')
                multi = Path("lib-multisrc/x/build.gradle.kts"); multi.parent.mkdir(parents=True)
                multi.write_text('baseVersionCode = 14\n')
                self.assertEqual(sync_upstream.effective_version_code(None, "src/pt/a")[2], 16)
            finally:
                os.chdir(previous)

    def test_missing_source_selector_is_inserted(self):
        result, changed = self.apply('source {\n}\n', 'libVersion = "1.6"\ntheme = "zeist"\n')
        self.assertTrue(changed)
        self.assertIn('theme = "zeist"', result)

    # Regression tests 15–22: deferred migrations remain explicit until a real
    # sandbox assembleDebug proves the protected source compatible.
    def test_15_old_divergent_api_is_deferred(self):
        report = {"theme": [{"unit": "src/pt/a", "migration_required": True, "migration_supported": False}]}
        self.assertIn("theme", sync_upstream.deferred_state(report, {"theme"}, "up"))

    def test_16_compatible_source_is_safe_to_migrate(self):
        row = {"unit": "src/pt/a", "migration_required": True, "migration_supported": True}
        self.assertTrue(row["migration_supported"])

    def test_17_failed_sandbox_keeps_old_metadata_deferred(self):
        result, _ = self.apply('libVersion = "1.4"\n', 'libVersion = "1.4"\n')
        self.assertIn('libVersion = "1.4"', result)
        self.assertIn("theme", sync_upstream.deferred_state({"theme": [{"unit": "src/pt/a", "migration_required": True}]}, {"theme"}, "up"))

    def test_18_safe_migration_preserves_source(self):
        result, _ = self.apply('libVersion = "1.4"\nsource { baseUrl = "https://nox" }\n', 'libVersion = "1.6"\n')
        self.assertIn('libVersion = "1.6"', result)
        self.assertIn('https://nox', result)

    def test_19_structural_migration_bumps_16_to_17_once(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = Path.cwd()
            try:
                os.chdir(directory)
                path = Path("src/pt/a/build.gradle.kts"); path.parent.mkdir(parents=True)
                path.write_text('versionCode = 2\ntheme = "x"\nlibVersion = "1.6"\n')
                multi = Path("lib-multisrc/x/build.gradle.kts"); multi.parent.mkdir(parents=True)
                multi.write_text('baseVersionCode = 14\n')
                old = sync_upstream.effective_version_code(None, "src/pt/a")
                self.assertTrue(sync_upstream.bump_after_structural_change("src/pt/a", old))
                self.assertEqual(sync_upstream.effective_version_code(None, "src/pt/a")[2], 17)
            finally:
                os.chdir(previous)

    def test_20_second_run_does_not_bump_17(self):
        with tempfile.TemporaryDirectory() as directory:
            previous = Path.cwd()
            try:
                os.chdir(directory)
                path = Path("src/pt/a/build.gradle.kts"); path.parent.mkdir(parents=True)
                path.write_text('versionCode = 3\ntheme = "x"\nlibVersion = "1.6"\n')
                multi = Path("lib-multisrc/x/build.gradle.kts"); multi.parent.mkdir(parents=True)
                multi.write_text('baseVersionCode = 14\n')
                _, changed = self.apply('libVersion = "1.6"\n', 'libVersion = "1.6"\n')
                self.assertFalse(changed)  # apply_units consequently never invokes the guard again.
                self.assertEqual(sync_upstream.effective_version_code(None, "src/pt/a")[2], 17)
            finally:
                os.chdir(previous)

    def test_21_deferred_survives_unrelated_upstream_advance(self):
        report = {"theme": [{"unit": "src/pt/a", "migration_required": True}]}
        self.assertEqual(sync_upstream.deferred_state(report, {"theme"}, "upstream/two")["theme"]["upstream_ref"], "upstream/two")

    def test_22_resolved_deferred_is_removed(self):
        self.assertEqual(sync_upstream.deferred_state({"theme": []}, set(), "upstream/three"), {})

    def test_shared_theme_stays_deferred_until_all_protected_sources_are_safe(self):
        rows = [
            {"unit": "src/pt/a", "migration_required": True, "migration_supported": True},
            {"unit": "src/pt/b", "migration_required": True, "migration_supported": False},
        ]
        blocked = {"theme"} if any(r["migration_required"] and not r["migration_supported"] for r in rows) else set()
        self.assertEqual(blocked, {"theme"})
        self.assertEqual(sync_upstream.deferred_state({"theme": rows}, blocked, "up")["theme"]["units"], ["src/pt/a", "src/pt/b"])
    def test_case_1_successful_structural_migration(self):
        """Case 1: Upstream bumps multisrc and extension; protected extension builds cleanly -> migration accepted."""
        with tempfile.TemporaryDirectory() as directory:
            prev = Path.cwd()
            try:
                os.chdir(directory)
                # Local state: ext and multisrc at 1.4
                ext = Path("src/pt/sample/build.gradle.kts")
                ext.parent.mkdir(parents=True)
                ext.write_text('versionCode = 10\ntheme = "mytheme"\nlibVersion = "1.4"\n\nsource {\n    baseUrl = "https://custom.nox"\n}\n')
                multi = Path("lib-multisrc/mytheme/build.gradle.kts")
                multi.parent.mkdir(parents=True)
                multi.write_text('baseVersionCode = 20\nlibVersion = "1.4"\n')

                # Upstream state: ext and multisrc at 1.6
                up_ext_content = 'versionCode = 5\ntheme = "mytheme"\nlibVersion = "1.6"\n'
                with patch.object(sync_upstream, "_read_file_text", return_value=up_ext_content):
                    changed = sync_upstream.merge_structural_metadata("src/pt/sample", "upstream/main")

                self.assertTrue(changed)
                res_text = ext.read_text()
                self.assertIn('libVersion = "1.6"', res_text)
                self.assertIn('baseUrl = "https://custom.nox"', res_text)

                # A libVersion migration is already newer without incrementing the suffix.
                old_info = sync_upstream.ExtensionVersion(10, 20, 30, "1.4")
                multi.write_text('baseVersionCode = 20\nlibVersion = "1.6"\n')
                bumped = sync_upstream.bump_after_structural_change("src/pt/sample", old_info)
                self.assertFalse(bumped)
                new_info = sync_upstream.effective_version_code(None, "src/pt/sample")
                self.assertGreater(new_info.android_code, old_info.android_code)
            finally:
                os.chdir(prev)

    def test_case_2_incompatible_structural_conflict_atomic_deferral(self):
        """Case 2: Protected unit fails proof build -> entire theme and all its extensions deferred atomically."""
        with tempfile.TemporaryDirectory() as directory:
            prev = Path.cwd()
            try:
                os.chdir(directory)
                # Create 3 extensions under theme "broken":
                # ext_a (protected, incompatible), ext_b (normal), ext_c (normal)
                for name in ("ext_a", "ext_b", "ext_c"):
                    p = Path(f"src/pt/{name}/build.gradle.kts")
                    p.parent.mkdir(parents=True)
                    p.write_text('versionCode = 1\ntheme = "broken"\nlibVersion = "1.4"\n')
                multi = Path("lib-multisrc/broken/build.gradle.kts")
                multi.parent.mkdir(parents=True)
                multi.write_text('baseVersionCode = 10\nlibVersion = "1.4"\n')

                # In preflight: theme "broken" is blocked because proof build fails
                blocked_themes = {"broken"}
                local_deps = sync_upstream.dependency_map(None)
                self.assertEqual(sorted(local_deps.get("broken", [])), ["src/pt/ext_a", "src/pt/ext_b", "src/pt/ext_c"])

                # Atomic deferral calculation
                blocked_theme_extensions = {
                    ext
                    for theme in blocked_themes
                    for ext in local_deps.get(theme, [])
                }
                # All 3 extensions MUST be blocked from upstream application
                self.assertEqual(blocked_theme_extensions, {"src/pt/ext_a", "src/pt/ext_b", "src/pt/ext_c"})

                # Compatibility validation: since none were upgraded without the multisrc, 0 errors
                errors = sync_upstream.validate_multisrc_compatibility()
                self.assertEqual(errors, [])

                # Deferred migrations recorded
                report = {"broken": [{"unit": "src/pt/ext_a", "migration_required": True}]}
                state = sync_upstream.deferred_state(report, blocked_themes, "upstream/main")
                self.assertIn("broken", state)
            finally:
                os.chdir(prev)

    def test_case_3_standalone_extension_isolated_deferral(self):
        """Case 3: Extension without multisrc theme that fails is isolated and does not affect other units."""
        with tempfile.TemporaryDirectory() as directory:
            prev = Path.cwd()
            try:
                os.chdir(directory)
                # Standalone extension has no theme in build.gradle.kts
                standalone = Path("src/pt/standalone/build.gradle.kts")
                standalone.parent.mkdir(parents=True)
                standalone.write_text('versionCode = 5\nlibVersion = "1.4"\n')

                normal_multi = Path("lib-multisrc/goodtheme/build.gradle.kts")
                normal_multi.parent.mkdir(parents=True)
                normal_multi.write_text('baseVersionCode = 1\nlibVersion = "1.6"\n')

                normal_ext = Path("src/pt/normal/build.gradle.kts")
                normal_ext.parent.mkdir(parents=True)
                normal_ext.write_text('versionCode = 1\ntheme = "goodtheme"\nlibVersion = "1.6"\n')

                deps = sync_upstream.dependency_map(None)
                self.assertNotIn("src/pt/standalone", deps.get("goodtheme", []))
                # Standalone extension is not in dependency_map of any multisrc theme
                self.assertNotIn("src/pt/standalone", [u for units in deps.values() for u in units])
            finally:
                os.chdir(prev)

    def test_case_4_version_code_guarantee_nox_always_ahead(self):
        """Case 4: Version guard guarantees Nox effective versionCode > upstream effective versionCode."""
        with tempfile.TemporaryDirectory() as directory:
            prev = Path.cwd()
            try:
                os.chdir(directory)
                ext = Path("src/pt/sample/build.gradle.kts")
                ext.parent.mkdir(parents=True)
                ext.write_text('versionCode = 12\ntheme = "theme"\nlibVersion = "1.6"\n')
                multi = Path("lib-multisrc/theme/build.gradle.kts")
                multi.parent.mkdir(parents=True)
                multi.write_text('baseVersionCode = 34\nlibVersion = "1.6"\n')

                # Local effective: 12 + 34 = 46.
                # Upstream effective: 15 + 34 = 49.
                up_content = 'versionCode = 15\ntheme = "theme"\nlibVersion = "1.6"\n'
                orig_read = sync_upstream._read_file_text

                def fake_read(ref, path):
                    if ref == "upstream/main":
                        if "lib-multisrc" in path:
                            return 'baseVersionCode = 34\nlibVersion = "1.6"\n'
                        return up_content
                    return orig_read(ref, path)

                with patch.object(sync_upstream, "_read_file_text", side_effect=fake_read):
                    res = sync_upstream.bump_version_code_if_needed("src/pt/sample", "upstream/main")

                self.assertIsNotNone(res)
                loc_raw, loc_base, loc_eff, up_raw, up_base, up_eff, new_raw = res
                self.assertEqual(loc_eff, 46)
                self.assertEqual(up_eff, 49)
                self.assertEqual(new_raw, 16)  # desired 50 - 34 = 16
                self.assertGreater(new_raw + loc_base, up_eff)
            finally:
                os.chdir(prev)

    def test_case_5_validate_multisrc_compatibility_clean(self):
        """Case 5: validate_multisrc_compatibility() returns empty list when all versions match."""
        with tempfile.TemporaryDirectory() as directory:
            prev = Path.cwd()
            try:
                os.chdir(directory)
                for t in ("theme1", "theme2"):
                    m = Path(f"lib-multisrc/{t}/build.gradle.kts")
                    m.parent.mkdir(parents=True)
                    m.write_text('baseVersionCode = 0\nlibVersion = "1.6"\n')
                    e = Path(f"src/pt/{t}_ext/build.gradle.kts")
                    e.parent.mkdir(parents=True)
                    e.write_text(f'versionCode = 1\ntheme = "{t}"\nlibVersion = "1.6"\n')

                errors = sync_upstream.validate_multisrc_compatibility()
                self.assertEqual(errors, [])
            finally:
                os.chdir(prev)


class GitFixture(unittest.TestCase):
    def setUp(self):
        self.previous = Path.cwd()
        self.directory = tempfile.TemporaryDirectory(prefix="nox-dependency-test-")
        os.chdir(self.directory.name)
        self.addCleanup(self.cleanup)
        self.git("init", "-q")
        self.git("config", "user.email", "test@invalid")
        self.git("config", "user.name", "Sync test")

    def cleanup(self):
        os.chdir(self.previous)
        self.directory.cleanup()

    def git(self, *args):
        return subprocess.run(["git", *args], capture_output=True, text=True, check=True).stdout.strip()

    def write(self, path, content):
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)

    def commit(self, message):
        self.git("add", ".")
        self.git("commit", "-qm", message)
        return self.git("rev-parse", "HEAD")


class LocalProjectDependencyTest(GitFixture):
    def test_missing_protected_dependency_blocks_sync_before_commit(self):
        self.write(".github/nox-protected.txt", "src/pt/protected\n")
        self.write(
            "src/pt/protected/build.gradle.kts",
            'dependencies { api(project(":lib:removed")) }\n',
        )
        self.write("base.txt", "base\n")
        base = self.commit("base")
        self.git("branch", "upstream")
        self.write("upstream.txt", "upstream\n")
        self.commit("upstream")
        self.git("checkout", "-q", "-B", "nox", base)

        with self.assertRaises(SystemExit):
            sync_upstream.apply_units("upstream", ["upstream.txt"], set(), [], [], set(), {})

        self.assertFalse(Path("upstream.txt").exists())
        self.assertFalse(Path(".git/MERGE_HEAD").exists())
        self.assertEqual(
            sync_upstream.validate_local_project_dependencies(),
            ["src/pt/protected/build.gradle.kts:1: :lib:removed -> lib/removed não existe"],
        )

    def test_existing_local_dependency_is_valid(self):
        self.write("lib/available/build.gradle.kts", "plugins {}\n")
        self.write(
            "src/pt/extension/build.gradle.kts",
            'dependencies { implementation(project(":lib:available")) }\n',
        )
        self.assertEqual(sync_upstream.validate_local_project_dependencies(), [])

    def test_protected_nox_unit_preserves_local_identity_and_extra_files(self):
        unit = "src/pt/pointzerotoons"
        self.write(".github/nox-protected.txt", f"{unit}\n")
        self.write(
            f"{unit}/build.gradle.kts",
            'name = "Kitsune Yako"\nversionCode = 3\n',
        )
        self.write(f"{unit}/PointZeroToons.kt", "class PointZeroToons // Nox\n")
        self.write(f"{unit}/PointZeroToonsParser.kt", "class PointZeroToonsParser // Nox\n")
        base = self.commit("base")

        self.git("branch", "upstream")
        self.git("checkout", "-q", "upstream")
        self.write(f"{unit}/build.gradle.kts", 'name = "Point Zero Toons"\nversionCode = 2\n')
        self.git("rm", f"{unit}/PointZeroToonsParser.kt")
        self.commit("upstream changes")
        self.git("checkout", "-q", "-B", "nox", base)

        protected = sync_upstream.get_protected_nox_units(base, "upstream")
        self.assertIn(unit, protected)
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [unit], {unit}, protected, [], set(), {})

        self.assertIn('name = "Kitsune Yako"', Path(f"{unit}/build.gradle.kts").read_text())
        self.assertIn("versionCode = 3", Path(f"{unit}/build.gradle.kts").read_text())
        self.assertTrue(Path(f"{unit}/PointZeroToons.kt").is_file())
        self.assertTrue(Path(f"{unit}/PointZeroToonsParser.kt").is_file())

    def test_protected_nox_unit_is_preserved_when_upstream_deletes_it(self):
        unit = "src/pt/karikari"
        self.write(".github/nox-protected.txt", f"{unit}\n")
        self.write(f"{unit}/build.gradle.kts", "versionCode = 1\n")
        self.write(f"{unit}/KariKari.kt", "class KariKari\n")
        base = self.commit("base")

        self.git("branch", "upstream")
        self.git("checkout", "-q", "upstream")
        self.git("rm", "-r", unit)
        self.commit("upstream deletes local-only unit")
        self.git("checkout", "-q", "-B", "nox", base)

        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [unit], set(), [unit], [], set(), {})

        self.assertTrue(Path(f"{unit}/build.gradle.kts").is_file())
        self.assertTrue(Path(f"{unit}/KariKari.kt").is_file())

    def test_global_version_guard_blocks_unprotected_downgrade(self):
        unit = "src/pt/onereader"
        self.write(f"{unit}/build.gradle.kts", 'versionCode = 3\nlibVersion = "1.6"\n')
        self.write(f"{unit}/OneReader.kt", "reader = new\n")
        base = self.commit("base")

        self.git("branch", "upstream")
        self.git("checkout", "-q", "upstream")
        self.write(f"{unit}/build.gradle.kts", 'versionCode = 2\nlibVersion = "1.6"\n')
        self.write(f"{unit}/OneReader.kt", "reader = old\n")
        self.commit("upstream downgrade")
        self.git("checkout", "-q", "-B", "nox", base)

        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [unit], set(), [], [], set(), {})

        self.assertIn("versionCode = 3", Path(f"{unit}/build.gradle.kts").read_text())
        self.assertIn("reader = new", Path(f"{unit}/OneReader.kt").read_text())

    def test_version_guard_noop_exits_without_an_empty_commit(self):
        unit = "src/tr/korelimanga"
        self.write(f"{unit}/build.gradle.kts", 'versionCode = 2\nlibVersion = "1.6"\n')
        base = self.commit("base")
        self.git("branch", "upstream", base)
        self.write(f"{unit}/build.gradle.kts", 'versionCode = 3\nlibVersion = "1.6"\n')
        before = self.commit("local version ahead")

        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [unit], set(), [], [], set(), {})

        self.assertEqual(self.git("rev-parse", "HEAD"), before)
        self.assertFalse(Path(".git/MERGE_HEAD").exists())
        self.assertEqual(self.git("diff", "--cached", "--name-only"), "")

    def test_new_upstream_merge_is_committed_even_when_version_guard_preserves_tree(self):
        unit = "src/tr/korelimanga"
        self.write(f"{unit}/build.gradle.kts", 'versionCode = 2\nlibVersion = "1.6"\n')
        base = self.commit("base")
        self.git("branch", "upstream", base)
        self.write(f"{unit}/build.gradle.kts", 'versionCode = 3\nlibVersion = "1.6"\n')
        before = self.commit("local version ahead")
        self.git("checkout", "-q", "upstream")
        self.write("upstream.txt", "new upstream ancestry\n")
        self.commit("upstream advance")
        self.git("checkout", "-q", "master")

        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [unit], set(), [], [], set(), {})

        self.assertNotEqual(self.git("rev-parse", "HEAD"), before)
        self.assertEqual(len(self.git("show", "-s", "--format=%P", "HEAD").split()), 2)
        self.assertFalse(Path(".git/MERGE_HEAD").exists())


class VersionOnlyAheadMigrationTest(GitFixture):
    unit = "src/en/qiscans"

    def gradle(self, version_code, theme=None, lib_version="1.6", extra=""):
        theme_line = f'theme = "{theme}"\n' if theme else ""
        return (
            f'versionCode = {version_code}\n'
            f'libVersion = "{lib_version}"\n'
            f"{theme_line}"
            f"{extra}"
        )

    def prepare(self, theme=None, upstream_base=None):
        if theme:
            self.write(
                f"lib-multisrc/{theme}/build.gradle.kts",
                'baseVersionCode = 0\nlibVersion = "1.6"\n',
            )
        self.write(f"{self.unit}/build.gradle.kts", self.gradle(0, theme))
        self.write(f"{self.unit}/src/Source.kt", "upstream old source\n")
        base = self.commit("upstream snapshot")

        self.git("checkout", "-qb", "upstream")
        if theme and upstream_base is not None:
            self.write(
                f"lib-multisrc/{theme}/build.gradle.kts",
                f'baseVersionCode = {upstream_base}\nlibVersion = "1.6"\n',
            )
        self.write(f"{self.unit}/build.gradle.kts", self.gradle(1, theme))
        self.write(f"{self.unit}/src/Source.kt", "upstream new source\n")
        self.commit("upstream functional update")

        self.git("checkout", "-q", "-B", "nox", base)
        self.write(f"{self.unit}/build.gradle.kts", self.gradle(25, theme))
        self.commit("Nox publication metadata")

    def test_version_only_ahead_imports_new_upstream_code_and_is_idempotent(self):
        self.prepare()

        self.assertTrue(sync_upstream.unit_matches_upstream_history(self.unit, "upstream"))
        self.assertTrue(sync_upstream.has_newer_upstream_for_version_only_unit(self.unit, "upstream"))
        self.assertEqual(sync_upstream.pending_sync_units([self.unit], [], "upstream"), [self.unit])
        with patch.object(sync_upstream, "validate_affected_builds") as validate:
            sync_upstream.apply_units("upstream", [self.unit], {self.unit}, [], [], set(), {})

        validate.assert_called_once_with([self.unit])
        self.assertEqual(Path(f"{self.unit}/src/Source.kt").read_text(), "upstream new source\n")
        result = sync_upstream.effective_version_code(None, self.unit)
        self.assertEqual((result.name, result.android_code), ("1.6.26", 106026))
        self.assertFalse(sync_upstream.has_newer_upstream_for_version_only_unit(self.unit, "upstream"))
        self.assertEqual(sync_upstream.pending_sync_units([self.unit], [], "upstream"), [])

    def test_functional_nox_change_remains_local_ahead(self):
        self.prepare()
        self.write(f"{self.unit}/src/Source.kt", "functional Nox customization\n")
        self.commit("Nox functional change")

        self.assertFalse(sync_upstream.has_newer_upstream_for_version_only_unit(self.unit, "upstream"))
        self.assertEqual(sync_upstream.pending_sync_units([self.unit], [], "upstream"), [])
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [self.unit], {self.unit}, [], [], set(), {})

        self.assertEqual(Path(f"{self.unit}/src/Source.kt").read_text(), "functional Nox customization\n")
        self.assertIn("versionCode = 25", Path(f"{self.unit}/build.gradle.kts").read_text())

    def test_version_only_history_requires_no_functional_gradle_difference(self):
        self.prepare()
        self.write(
            f"{self.unit}/build.gradle.kts",
            self.gradle(25, extra='dependencies { implementation(project(":lib:custom")) }\n'),
        )
        self.commit("Nox dependency customization")
        self.assertFalse(sync_upstream.unit_matches_upstream_history(self.unit, "upstream"))
        self.assertFalse(sync_upstream.has_newer_upstream_for_version_only_unit(self.unit, "upstream"))

    def test_assets_are_not_ignored_as_version_metadata(self):
        self.prepare()
        self.write(f"{self.unit}/assets/config.json", "Nox customization\n")
        self.commit("Nox asset customization")

        self.assertFalse(sync_upstream.unit_matches_upstream_history(self.unit, "upstream"))
        self.assertFalse(sync_upstream.has_newer_upstream_for_version_only_unit(self.unit, "upstream"))

    def test_theme_and_lib_version_are_not_ignored_as_version_metadata(self):
        self.prepare()
        self.write(f"{self.unit}/build.gradle.kts", self.gradle(25, "other"))
        self.commit("Nox theme customization")
        self.assertFalse(sync_upstream.has_newer_upstream_for_version_only_unit(self.unit, "upstream"))

        self.git("reset", "--hard", "HEAD~1")
        self.write(f"{self.unit}/build.gradle.kts", self.gradle(25, lib_version="1.7"))
        self.commit("Nox library customization")
        self.assertFalse(sync_upstream.has_newer_upstream_for_version_only_unit(self.unit, "upstream"))

    def test_multisrc_base_and_raw_version_bump_to_next_public_version(self):
        theme = "sample"
        self.prepare(theme, upstream_base=10)

        with patch.object(sync_upstream, "validate_affected_builds") as validate:
            sync_upstream.apply_units(
                "upstream",
                [f"lib-multisrc/{theme}", self.unit],
                {self.unit},
                [],
                [],
                set(),
                {},
            )

        validate.assert_called_once_with([self.unit])
        result = sync_upstream.effective_version_code(None, self.unit)
        self.assertEqual((result.raw, result.base, result.name, result.android_code), (16, 10, "1.6.26", 106026))
        self.assertEqual(sync_upstream.pending_sync_units([self.unit], [], "upstream"), [])

    def test_protected_unit_stays_preserved_even_when_version_only(self):
        self.prepare()

        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [self.unit], {self.unit}, [self.unit], [], set(), {})

        self.assertEqual(Path(f"{self.unit}/src/Source.kt").read_text(), "upstream old source\n")
        self.assertIn("versionCode = 25", Path(f"{self.unit}/build.gradle.kts").read_text())


class PublicationVersionTest(unittest.TestCase):
    unit = "src/ja/cycomi"

    def version(self, lib, raw, base=0):
        return sync_upstream.ExtensionVersion(raw, base, raw + base, lib)

    def compare(self, local, upstream):
        with patch.object(sync_upstream, "effective_version_code", side_effect=[local, upstream]):
            return sync_upstream.local_version_ahead_of_upstream(self.unit, "upstream")

    def test_library_migration_is_newer_despite_raw_reset(self):
        local = self.version("1.4", 2)
        upstream = self.version("1.6", 1)
        self.assertEqual((local.android_code, upstream.android_code), (104002, 106001))
        self.assertIsNone(self.compare(local, upstream))
        with patch.object(sync_upstream, "effective_version_code", side_effect=[local, upstream]):
            self.assertEqual(sync_upstream.pending_sync_units([self.unit], [], "upstream"), [self.unit])

    def test_same_library_preserves_local_ahead(self):
        local = self.version("1.6", 64)
        upstream = self.version("1.6", 60)
        self.assertEqual(self.compare(local, upstream), (local, upstream))

    def test_multisrc_uses_base_and_raw_in_publication(self):
        local = self.version("1.6", 9, 55)
        upstream = self.version("1.6", 4, 55)
        self.assertEqual((local.name, local.android_code), ("1.6.64", 106064))
        self.assertEqual(self.compare(local, upstream), (local, upstream))
        self.assertIsNone(self.compare(self.version("1.6", 9, 50), upstream))
        self.assertIsNone(self.compare(self.version("1.6", 9, 49), upstream))

    def test_metadata_reader_combines_library_theme_and_raw(self):
        files = {
            f"{self.unit}/build.gradle.kts": 'libVersion = "1.6"\ntheme = "madara"\nversionCode = 9\n',
            "lib-multisrc/madara/build.gradle.kts": 'libVersion = "1.6"\nbaseVersionCode = 55\n',
        }
        with patch.object(sync_upstream, "_read_file_text", side_effect=lambda ref, path: files.get(path)):
            version = sync_upstream.effective_version_code(None, self.unit)
        self.assertEqual(version, self.version("1.6", 9, 55))
        self.assertEqual(version.android_code, 106064)

    def test_lib_downgrade_is_blocked_even_with_larger_raw(self):
        local = self.version("1.6", 1)
        upstream = self.version("1.4", 99)
        self.assertEqual(self.compare(local, upstream), (local, upstream))

    def test_protected_old_library_does_not_encode_migration_in_raw_version(self):
        with patch.object(sync_upstream, "effective_version_code", side_effect=[
            self.version("1.4", 2), self.version("1.6", 1),
        ]), patch.object(Path, "write_text") as write:
            self.assertIsNone(sync_upstream.bump_version_code_if_needed(self.unit, "upstream"))
            write.assert_not_called()

    def test_validation_compiles_kotlin_not_just_metadata(self):
        with patch.object(Path, "exists", return_value=True), patch.object(
            sync_upstream.subprocess, "run", return_value=SimpleNamespace(returncode=0),
        ) as run:
            sync_upstream.validate_affected_builds([self.unit])
        self.assertEqual(run.call_args.args[0], [
            "./gradlew", ":src:ja:cycomi:generateSourceInfo", ":src:ja:cycomi:compileReleaseKotlin",
        ])


class StandaloneMigrationTest(GitFixture):
    def migration_history(self, protected=False):
        unit = "src/ja/cycomi"
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.4"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "HttpSource; rc4(key, bytes)\n")
        self.write("core/utils/RC4.kt", "rc4(key, bytes)\n")
        base = self.commit("old shared API")
        self.git("checkout", "-qb", "upstream")
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.6"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "KeiSource; source.rc4(key)\n")
        self.write("core/utils/RC4.kt", "Source.rc4(key)\n")
        self.commit("migrate API and dependent together")
        self.git("checkout", "-q", "-B", "nox", base)
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.4"\nversionCode = 2\n')
        if protected:
            self.write(f"{unit}/src/Source.kt", "custom Nox implementation\n")
        self.commit("local publication")
        return unit

    def test_standalone_migration_copies_complete_source_and_validates(self):
        unit = self.migration_history()
        real_git = sync_upstream.git
        def no_commit(*args, **kwargs):
            if args[0] == "commit":
                return ""
            return real_git(*args, **kwargs)
        with patch.object(sync_upstream, "validate_affected_builds") as validate, patch.object(
            sync_upstream, "git", side_effect=no_commit,
        ):
            sync_upstream.apply_units("upstream", ["core", unit], {unit}, [], [], set(), {})
        validate.assert_called_once_with([unit])
        self.assertEqual(Path(f"{unit}/src/Source.kt").read_text(), "KeiSource; source.rc4(key)\n")
        self.assertEqual(Path("core/utils/RC4.kt").read_text(), "Source.rc4(key)\n")
        self.assertEqual(sync_upstream.effective_version_code(None, unit).android_code, 106001)

    def test_multisrc_base_replacement_does_not_change_downgrade_comparison(self):
        unit = "src/pt/sample"
        theme = "lib-multisrc/sample"
        self.write(f"{theme}/build.gradle.kts", 'libVersion = "1.6"\nbaseVersionCode = 50\n')
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.6"\ntheme = "sample"\nversionCode = 9\n')
        base = self.commit("local publication 1.6.59")
        self.git("checkout", "-qb", "upstream")
        self.write(f"{theme}/build.gradle.kts", 'libVersion = "1.6"\nbaseVersionCode = 55\n')
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.6"\ntheme = "sample"\nversionCode = 4\n')
        self.commit("upstream publication 1.6.59 with different base")
        self.git("checkout", "-q", "-B", "nox", base)
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [theme, unit], set(), [], [], set(), {})
        result = sync_upstream.effective_version_code(None, unit)
        self.assertEqual((result.raw, result.base, result.android_code), (5, 55, 106060))

    def test_pending_after_ours_merge_recovers_standalone_migration(self):
        unit = self.migration_history()
        self.git("merge", "--no-ff", "-s", "ours", "upstream", "-m", "old broken sync")
        self.assertEqual(sync_upstream.pending_sync_units([unit], [], "upstream"), [unit])
        self.assertEqual(sync_upstream.unprotected_structural_migrations([unit], [], "upstream"), {unit})
        self.assertTrue(sync_upstream.unit_matches_upstream_history(unit, "upstream"))

    def test_multisrc_preflight_blocks_semantic_lib_downgrade(self):
        theme = "lib-multisrc/sample"
        unit = "src/pt/sample"
        self.write(f"{theme}/build.gradle.kts", 'libVersion = "1.6"\nbaseVersionCode = 1\n')
        self.write(
            f"{unit}/build.gradle.kts",
            'libVersion = "1.6"\ntheme = "sample"\nversionCode = 1\n',
        )
        base = self.commit("local 1.6 structure")
        self.git("checkout", "-qb", "upstream")
        self.write(f"{theme}/build.gradle.kts", 'libVersion = "1.4"\nbaseVersionCode = 99\n')
        self.write(
            f"{unit}/build.gradle.kts",
            'libVersion = "1.4"\ntheme = "sample"\nversionCode = 99\n',
        )
        self.commit("upstream 1.4 structure")
        self.git("checkout", "-q", "-B", "nox", base)

        report, blocked = sync_upstream.preflight_multisrc(base, "upstream", [])

        self.assertEqual(blocked, {"sample"})
        self.assertTrue(report["sample"][0]["libVersion_downgrade"])
        self.assertEqual(self.git("status", "--porcelain"), "")

    def test_preflight_candidate_preserves_non_source_customization(self):
        theme = "lib-multisrc/sample"
        unit = "src/pt/sample"
        self.write(f"{theme}/build.gradle.kts", 'libVersion = "1.4"\nbaseVersionCode = 1\n')
        self.write(
            f"{unit}/build.gradle.kts",
            'libVersion = "1.4"\ntheme = "sample"\nversionCode = 1\n',
        )
        self.write(f"{unit}/src/Source.kt", "shared source\n")
        self.write(f"{unit}/assets/config.json", "base\n")
        self.write(
            "gradlew",
            "#!/bin/sh\n"
            "grep -qx 'Nox customization' src/pt/sample/assets/config.json\n"
            "grep -q 'libVersion = \"1.6\"' src/pt/sample/build.gradle.kts\n",
        )
        Path("gradlew").chmod(0o755)
        base = self.commit("base")
        self.git("checkout", "-qb", "upstream")
        self.write(f"{theme}/build.gradle.kts", 'libVersion = "1.6"\nbaseVersionCode = 1\n')
        self.write(
            f"{unit}/build.gradle.kts",
            'libVersion = "1.6"\ntheme = "sample"\nversionCode = 1\n',
        )
        self.write(f"{unit}/src/Source.kt", "upstream source\n")
        self.write(f"{unit}/assets/config.json", "upstream\n")
        self.commit("upstream structural migration")
        self.git("checkout", "-q", "-B", "nox", base)
        self.write(f"{unit}/assets/config.json", "Nox customization\n")
        self.commit("Nox asset customization")
        before = self.git("rev-parse", "HEAD")

        report, blocked = sync_upstream.preflight_multisrc(base, "upstream", [])
        self.assertEqual(blocked, set())
        self.assertFalse(report["sample"][0]["source_divergent"])
        self.assertTrue(report["sample"][0]["unit_divergent"])
        self.assertEqual(sync_upstream.verify_migration_plan(report, "upstream"), set())

        self.assertEqual(self.git("rev-parse", "HEAD"), before)
        self.assertEqual(self.git("status", "--porcelain"), "")

    def test_structural_lib_downgrade_is_rejected_before_merge(self):
        unit = "src/ja/cycomi"
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.6"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "local 1.6 source\n")
        base = self.commit("local 1.6 source")
        self.git("checkout", "-qb", "upstream")
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.4"\nversionCode = 99\n')
        self.write(f"{unit}/src/Source.kt", "upstream 1.4 source\n")
        self.commit("upstream 1.4 source")
        self.git("checkout", "-q", "-B", "nox", base)
        before = self.git("rev-parse", "HEAD")

        with self.assertRaisesRegex(RuntimeError, "downgrade blocked before merge"):
            sync_upstream.apply_units("upstream", [unit], {unit}, [], [unit], set(), {})

        self.assertEqual(self.git("rev-parse", "HEAD"), before)
        self.assertEqual(self.git("status", "--porcelain"), "")
        self.assertFalse(Path(".git/MERGE_HEAD").exists())
        self.assertEqual(Path(f"{unit}/src/Source.kt").read_text(), "local 1.6 source\n")
        self.assertIn('libVersion = "1.6"', Path(f"{unit}/build.gradle.kts").read_text())

    def test_protected_outside_source_customization_is_never_restored(self):
        unit = "src/ja/cycomi"
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.4"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "shared old source\n")
        self.write(f"{unit}/assets/config.json", "base\n")
        base = self.commit("base")
        self.git("checkout", "-qb", "upstream")
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.6"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "upstream new source\n")
        self.write(f"{unit}/assets/config.json", "upstream\n")
        self.commit("upstream structural migration")
        self.git("checkout", "-q", "-B", "nox", base)
        self.write(f"{unit}/assets/config.json", "Nox customization\n")
        self.commit("Nox asset customization")

        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [unit], {unit}, [unit], [unit], set(), {})

        self.assertEqual(Path(f"{unit}/assets/config.json").read_text(), "Nox customization\n")
        self.assertEqual(Path(f"{unit}/src/Source.kt").read_text(), "shared old source\n")
        self.assertIn('libVersion = "1.4"', Path(f"{unit}/build.gradle.kts").read_text())

    def test_nonprotected_outside_source_customization_is_preserved_on_reconciliation(self):
        unit = "src/ja/cycomi"
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.4"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "shared old source\n")
        self.write(f"{unit}/assets/config.json", "base\n")
        base = self.commit("base")
        self.git("checkout", "-qb", "upstream")
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.6"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "upstream new source\n")
        self.write(f"{unit}/assets/config.json", "upstream\n")
        self.commit("upstream structural migration")
        self.git("checkout", "-q", "-B", "nox", base)
        self.write(f"{unit}/assets/config.json", "Nox customization\n")
        self.commit("Nox asset customization")

        with patch.object(sync_upstream, "validate_affected_builds") as validate:
            sync_upstream.apply_units("upstream", [unit], {unit}, [], [unit], set(), {})

        validate.assert_called_once_with([unit])
        self.assertEqual(Path(f"{unit}/assets/config.json").read_text(), "Nox customization\n")
        self.assertEqual(Path(f"{unit}/src/Source.kt").read_text(), "shared old source\n")
        self.assertIn('libVersion = "1.6"', Path(f"{unit}/build.gradle.kts").read_text())

    def test_failed_reconciliation_rolls_back_outside_source_customization(self):
        unit = "src/ja/cycomi"
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.4"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "shared old source\n")
        self.write(f"{unit}/assets/config.json", "base\n")
        base = self.commit("base")
        self.git("checkout", "-qb", "upstream")
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.6"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "upstream new source\n")
        self.commit("upstream structural migration")
        self.git("checkout", "-q", "-B", "nox", base)
        self.write(f"{unit}/assets/config.json", "Nox customization\n")
        self.commit("Nox asset customization")
        before = self.git("rev-parse", "HEAD")

        with patch.object(
            sync_upstream,
            "validate_affected_builds",
            side_effect=RuntimeError("incompatible reconciliation"),
        ):
            with self.assertRaises(SystemExit):
                sync_upstream.apply_units("upstream", [unit], {unit}, [], [unit], set(), {})

        self.assertEqual(self.git("rev-parse", "HEAD"), before)
        self.assertEqual(self.git("status", "--porcelain"), "")
        self.assertFalse(Path(".git/MERGE_HEAD").exists())
        self.assertEqual(Path(f"{unit}/assets/config.json").read_text(), "Nox customization\n")
        self.assertIn('libVersion = "1.4"', Path(f"{unit}/build.gradle.kts").read_text())

    def test_unexpected_structural_failure_aborts_the_open_merge(self):
        unit = "src/ja/cycomi"
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.4"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "shared old source\n")
        self.write(f"{unit}/assets/config.json", "base\n")
        base = self.commit("base")
        self.git("checkout", "-qb", "upstream")
        self.write(f"{unit}/build.gradle.kts", 'libVersion = "1.6"\nversionCode = 1\n')
        self.write(f"{unit}/src/Source.kt", "upstream new source\n")
        self.commit("upstream structural migration")
        self.git("checkout", "-q", "-B", "nox", base)
        self.write(f"{unit}/assets/config.json", "Nox customization\n")
        self.commit("Nox asset customization")
        before = self.git("rev-parse", "HEAD")

        with patch.object(
            sync_upstream,
            "merge_structural_metadata",
            side_effect=RuntimeError("unexpected structural failure"),
        ):
            with self.assertRaisesRegex(RuntimeError, "unexpected structural failure"):
                sync_upstream.apply_units("upstream", [unit], {unit}, [], [unit], set(), {})

        self.assertEqual(self.git("rev-parse", "HEAD"), before)
        self.assertEqual(self.git("status", "--porcelain"), "")
        self.assertFalse(Path(".git/MERGE_HEAD").exists())
        self.assertEqual(Path(f"{unit}/assets/config.json").read_text(), "Nox customization\n")
        self.assertIn('libVersion = "1.4"', Path(f"{unit}/build.gradle.kts").read_text())

    def test_protected_custom_source_is_not_migrated_implicitly(self):
        unit = self.migration_history(protected=True)
        self.assertFalse(sync_upstream.unit_matches_upstream_history(unit, "upstream"))
        self.assertEqual(sync_upstream.unprotected_structural_migrations([unit], [unit], "upstream"), set())
        before = Path(f"{unit}/build.gradle.kts").read_text()
        with patch.object(sync_upstream, "validate_affected_builds"), patch.object(
            sync_upstream, "has_staged_changes", return_value=False,
        ), patch.object(sync_upstream, "merge_in_progress", return_value=False):
            sync_upstream.apply_units("upstream", [unit], {unit}, [unit], [], set(), {})
        self.assertEqual(Path(f"{unit}/build.gradle.kts").read_text(), before)
        self.assertEqual(Path(f"{unit}/src/Source.kt").read_text(), "custom Nox implementation\n")

    def test_api_compile_failure_aborts_before_commit(self):
        unit = self.migration_history()
        before = self.git("rev-parse", "HEAD")
        with patch.object(sync_upstream, "validate_affected_builds", side_effect=RuntimeError("API mismatch")):
            with self.assertRaises(SystemExit):
                sync_upstream.apply_units("upstream", ["core", unit], {unit}, [], [], set(), {})
        self.assertEqual(self.git("rev-parse", "HEAD"), before)
        self.assertEqual(Path(f"{unit}/src/Source.kt").read_text(), "HttpSource; rc4(key, bytes)\n")
        self.assertFalse(Path(".git/MERGE_HEAD").exists())


class ProtectedMultisrcTest(unittest.TestCase):
    theme = "sample"
    unit = "lib-multisrc/sample"
    extensions = ["src/pt/one", "src/pt/two"]

    def setUp(self):
        self.previous = Path.cwd()
        self.directory = tempfile.TemporaryDirectory(prefix="nox-sync-test-")
        os.chdir(self.directory.name)
        self.addCleanup(self.cleanup)
        self.git("init", "-q")
        self.git("config", "user.email", "test@invalid")
        self.git("config", "user.name", "Sync test")
        self.write(f"{self.unit}/build.gradle.kts", 'libVersion = "1.6"\nbaseVersionCode = 3\n')
        self.write(f"{self.unit}/Reader.kt", "reader = old\n" + "\n" * 12 + "backend = old\n")
        for unit in self.extensions:
            self.write(f"{unit}/build.gradle.kts", 'versionCode = 1\ntheme = "sample"\nlibVersion = "1.6"\n')
        self.write("gradlew", "#!/usr/bin/env python3\nimport pathlib, sys\np = pathlib.Path('lib-multisrc/sample')\nassert 'reader = nox' in (p/'Reader.kt').read_text()\nassert 'too_fast' in (p/'Gate.kt').read_text()\nassert ':lib-multisrc:sample:testDebugUnitTest' in sys.argv\nfor name in ('one', 'two'):\n assert f':src:pt:{name}:assembleDebug' in sys.argv\n assert (p/'build.gradle.kts').read_text().splitlines()[0] in pathlib.Path(f'src/pt/{name}/build.gradle.kts').read_text()\n")
        Path("gradlew").chmod(0o755)
        self.base = self.commit("base")
        self.git("branch", "upstream", self.base)
        self.git("branch", "nox", self.base)
        self.git("checkout", "-q", "nox")

    def cleanup(self):
        os.chdir(self.previous)
        self.directory.cleanup()

    def git(self, *args):
        return subprocess.run(["git", *args], capture_output=True, text=True, check=True).stdout.strip()

    def write(self, path, text):
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text)

    def commit(self, message):
        self.git("add", ".")
        self.git("commit", "-qm", message)
        return self.git("rev-parse", "HEAD")

    def nox_patch(self):
        path = Path(f"{self.unit}/Reader.kt")
        path.write_text(path.read_text().replace("reader = old", "reader = nox"))
        self.write(f"{self.unit}/Gate.kt", "too_fast retry once\n")
        self.commit("functional Nox patch")

    def advance(self, conflict=False, structural=False, fail_build=False):
        self.git("checkout", "-q", "upstream")
        path = Path(f"{self.unit}/Reader.kt")
        path.write_text(path.read_text().replace("reader = old" if conflict else "backend = old", "reader = upstream" if conflict else "backend = new"))
        if structural:
            for path in [f"{self.unit}/build.gradle.kts", *(f"{unit}/build.gradle.kts" for unit in self.extensions)]:
                p = Path(path)
                p.write_text(p.read_text().replace('"1.6"', '"1.7"'))
        if fail_build:
            self.write("gradlew", "#!/bin/sh\nexit 1\n")
        self.write("unrelated.txt", "upstream advance\n")
        self.commit("upstream update")
        self.git("checkout", "-q", "nox")

    def prove(self):
        before = self.git("status", "--porcelain")
        index = self.git("write-tree")
        result = sync_upstream.prove_protected_multisrc(self.base, "upstream", [], set())
        self.assertEqual(self.git("status", "--porcelain"), before)
        self.assertEqual(self.git("write-tree"), index)
        return result

    def test_a_upstream_only_multisrc_is_not_protected(self):
        self.advance()
        self.assertEqual(sync_upstream.protected_multisrc_bases(self.base, "upstream"), {})
        self.assertEqual(self.prove(), ({}, {}))
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [self.unit], set(), [], [], set(), {})
        self.assertIn("backend = new", Path(f"{self.unit}/Reader.kt").read_text())

    def test_b_unchanged_upstream_preserves_patch_without_build(self):
        self.nox_patch()
        self.git("checkout", "-q", "upstream")
        self.write("unrelated.txt", "unrelated update\n")
        self.commit("unrelated upstream change")
        self.git("checkout", "-q", "nox")
        self.assertEqual(sync_upstream.protected_multisrc_bases(self.base, "upstream"), {self.theme: self.base})
        self.assertEqual(self.prove(), ({}, {}))
        self.assertIn("reader = nox", Path(f"{self.unit}/Reader.kt").read_text())

    def test_c_functional_merge_builds_all_dependents_and_tests(self):
        self.nox_patch()
        self.advance()
        accepted, deferred = self.prove()
        self.assertFalse(deferred)
        tree = accepted[self.theme]["tree"]
        reader = self.git("show", f"{tree}:{self.unit}/Reader.kt")
        self.assertIn("reader = nox", reader)
        self.assertIn("backend = new", reader)
        self.assertEqual(accepted[self.theme]["units"], self.extensions)

    def test_d_structural_upgrade_keeps_functional_delta(self):
        self.nox_patch()
        path = Path(f"{self.unit}/build.gradle.kts")
        path.write_text(path.read_text() + "\n// Nox test configuration\n")
        self.commit("test configuration")
        self.advance(structural=True)
        accepted, deferred = self.prove()
        self.assertFalse(deferred)
        tree = accepted[self.theme]["tree"]
        gradle = self.git("show", f"{tree}:{self.unit}/build.gradle.kts")
        self.assertIn('"1.7"', gradle)
        self.assertIn("Nox test configuration", gradle)
        self.assertIn("too_fast", self.git("show", f"{tree}:{self.unit}/Gate.kt"))

    def test_e_conflict_defers_theme_and_all_dependents(self):
        self.nox_patch()
        self.advance(conflict=True, structural=True)
        accepted, deferred = self.prove()
        self.assertFalse(accepted)
        self.assertEqual(deferred[self.theme]["patch_base"], self.base)
        self.assertEqual(deferred[self.theme]["units"], self.extensions)
        self.assertIn("functional conflict", deferred[self.theme]["reason"])

    def test_f_build_failure_defers_without_touching_main(self):
        self.nox_patch()
        self.advance(fail_build=True)
        accepted, deferred = self.prove()
        self.assertFalse(accepted)
        self.assertEqual(deferred[self.theme]["reason"], "proof build/tests failed")

    def test_g_deferred_retry_keeps_original_base_after_ours_merge(self):
        self.nox_patch()
        self.advance(conflict=True)
        _, deferred = self.prove()
        sync_upstream.write_deferred_migrations(deferred)
        self.commit("deferred backlog")
        self.git("merge", "-s", "ours", "--no-edit", "upstream")
        self.git("checkout", "-q", "upstream")
        path = Path(f"{self.unit}/Reader.kt")
        path.write_text(path.read_text().replace("reader = upstream", "reader = old").replace("backend = old", "backend = new"))
        self.commit("compatible upstream revision")
        self.git("checkout", "-q", "nox")
        new_base = self.git("merge-base", "HEAD", "upstream")
        self.assertNotEqual(new_base, self.base)
        self.assertEqual(sync_upstream.protected_multisrc_bases(new_base, "upstream"), {self.theme: self.base})
        accepted, deferred = sync_upstream.prove_protected_multisrc(new_base, "upstream", [], set())
        self.assertIn(self.theme, accepted)
        self.assertFalse(deferred)

    def test_h_upstream_deletion_of_patched_file_is_deferred(self):
        self.nox_patch()
        self.git("checkout", "-q", "upstream")
        self.git("rm", f"{self.unit}/Reader.kt")
        self.commit("remove old reader")
        self.git("checkout", "-q", "nox")
        accepted, deferred = self.prove()
        self.assertFalse(accepted)
        self.assertIn("add/delete conflict", deferred[self.theme]["reason"])

    def test_i_upstream_adopted_patch_needs_no_protection(self):
        self.nox_patch()
        self.git("branch", "-f", "upstream", "HEAD")
        self.assertEqual(sync_upstream.protected_multisrc_bases(self.base, "upstream"), {})

    def test_j_apply_uses_proven_tree_not_upstream_tree(self):
        self.nox_patch()
        self.advance(structural=True)
        proven, deferred = self.prove()
        units = sync_upstream.collect_units(sync_upstream.changed_entries(self.base, "upstream"))[0]
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", units, {self.unit}, [], [], set(), deferred, proven)
        self.assertIn("reader = nox", Path(f"{self.unit}/Reader.kt").read_text())
        self.assertIn("backend = new", Path(f"{self.unit}/Reader.kt").read_text())
        self.assertIn('"1.7"', Path(f"{self.unit}/build.gradle.kts").read_text())
        self.assertTrue(Path("unrelated.txt").exists())
        self.assertEqual(sync_upstream.validate_multisrc_compatibility(), [])
        self.assertFalse(sync_upstream.load_deferred_migrations())
        self.assertEqual(self.git("status", "--porcelain"), "")

    def test_j1_proven_migration_overrides_version_guard_atomically(self):
        self.nox_patch()
        for unit in self.extensions:
            self.write(f"{unit}/Nox.kt", "nox source\n")
            gradle = Path(f"{unit}/build.gradle.kts")
            gradle.write_text(gradle.read_text().replace("versionCode = 1", "versionCode = 7"))
        self.commit("protected dependents ahead")
        self.advance(structural=True)
        proven, deferred = sync_upstream.prove_protected_multisrc(self.base, "upstream", self.extensions, set())
        self.assertFalse(deferred)
        units = sync_upstream.collect_units(sync_upstream.changed_entries(self.base, "upstream"))[0]
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", units, {self.unit}, self.extensions, [], set(), deferred, proven)
        for unit in self.extensions:
            gradle = Path(f"{unit}/build.gradle.kts").read_text()
            self.assertIn('libVersion = "1.7"', gradle)
            self.assertIn("versionCode = 7", gradle)
            self.assertEqual(Path(f"{unit}/Nox.kt").read_text(), "nox source\n")
        self.assertEqual(sync_upstream.validate_multisrc_compatibility(), [])

    def test_j2_structural_migration_overrides_unprotected_version_guard(self):
        for unit in self.extensions:
            self.write(f"{unit}/src/Nox.kt", "local source\n")
            gradle = Path(f"{unit}/build.gradle.kts")
            gradle.write_text(gradle.read_text().replace("versionCode = 1", "versionCode = 7"))
        self.commit("local dependents ahead")
        self.advance(structural=True)
        units = sync_upstream.collect_units(sync_upstream.changed_entries(self.base, "upstream"))[0]
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", units, {self.unit}, [], self.extensions, set(), {}, {})
        for unit in self.extensions:
            gradle = Path(f"{unit}/build.gradle.kts").read_text()
            self.assertIn('libVersion = "1.7"', gradle)
            self.assertIn("versionCode = 7", gradle)
            self.assertEqual(Path(f"{unit}/src/Nox.kt").read_text(), "local source\n")
        self.assertEqual(sync_upstream.validate_multisrc_compatibility(), [])

    def test_k_apply_defers_atomically_and_keeps_unrelated_updates(self):
        self.nox_patch()
        self.advance(conflict=True, structural=True)
        proven, deferred = self.prove()
        units = sync_upstream.collect_units(sync_upstream.changed_entries(self.base, "upstream"))[0]
        before = {unit: Path(f"{unit}/build.gradle.kts").read_bytes() for unit in [self.unit, *self.extensions]}
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", units, {self.unit}, self.extensions, [], {self.theme}, deferred, proven)
        for unit, content in before.items():
            self.assertEqual(Path(f"{unit}/build.gradle.kts").read_bytes(), content)
        self.assertTrue(Path("unrelated.txt").exists())
        self.assertEqual(sync_upstream.load_deferred_migrations()[self.theme]["patch_base"], self.base)
        self.assertIn("reader = nox", Path(f"{self.unit}/Reader.kt").read_text())
        self.assertEqual(self.git("status", "--porcelain"), "")

    def test_l_unproven_protected_theme_cannot_be_applied(self):
        self.nox_patch()
        self.advance()
        head = self.git("rev-parse", "HEAD")
        with self.assertRaisesRegex(RuntimeError, "Unproven protected multisrc"):
            sync_upstream.apply_units("upstream", [self.unit], {self.unit}, [], [], set(), {})
        self.assertEqual(self.git("rev-parse", "HEAD"), head)
        self.assertFalse(Path(".git/MERGE_HEAD").exists())

    def test_m_shared_dependent_propagates_atomic_deferral(self):
        proven = {"second": {"tree": "tree", "units": [self.extensions[0]]}}
        deferred, blocked = {}, {self.theme}
        with patch.object(sync_upstream, "dependency_map", return_value={self.theme: self.extensions, "second": [self.extensions[0]]}):
            sync_upstream.propagate_multisrc_deferrals(proven, deferred, blocked, {"second": self.base}, "upstream")
        self.assertFalse(proven)
        self.assertEqual(blocked, {self.theme, "second"})
        self.assertEqual(deferred["second"]["patch_base"], self.base)

    def test_n_patch_is_protected_again_after_successful_sync(self):
        self.nox_patch()
        self.advance()
        proven, deferred = self.prove()
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units("upstream", [self.unit], {self.unit}, [], [], set(), deferred, proven)
        self.git("checkout", "-q", "upstream")
        path = Path(f"{self.unit}/Reader.kt")
        path.write_text(path.read_text() + "\nsecond upstream improvement\n")
        self.commit("second upstream update")
        self.git("checkout", "-q", "nox")
        base = self.git("merge-base", "HEAD", "upstream")
        proven, deferred = sync_upstream.prove_protected_multisrc(base, "upstream", [], set())
        self.assertFalse(deferred)
        reader = self.git("show", f"{proven[self.theme]['tree']}:{self.unit}/Reader.kt")
        self.assertIn("reader = nox", reader)
        self.assertIn("second upstream improvement", reader)

    def test_o_removing_protected_theme_is_deferred(self):
        self.nox_patch()
        self.git("checkout", "-q", "upstream")
        self.git("rm", "-r", self.unit)
        self.commit("remove theme")
        self.git("checkout", "-q", "nox")
        proven, deferred = self.prove()
        self.assertFalse(proven)
        self.assertIn("removed upstream", deferred[self.theme]["reason"])


class BladeToonsRegressionTest(GitFixture):
    theme = "mangotheme"
    theme_unit = "lib-multisrc/mangotheme"
    extension = "src/pt/bladetoons"

    def setUp(self):
        super().setUp()
        self.write(".github/nox-protected.txt", f"{self.extension}\n")
        # Base: mangotheme 1.4, baseVersionCode 3
        self.write(
            f"{self.theme_unit}/build.gradle.kts",
            'libVersion = "1.4"\nbaseVersionCode = 3\n',
        )
        # Base: BladeToons 1.4, raw versionCode 4 -> effective 7, pub 1.4.7 / 104007
        self.write(
            f"{self.extension}/build.gradle.kts",
            'libVersion = "1.4"\ntheme = "mangotheme"\nversionCode = 4\n',
        )
        self.write(
            f"{self.extension}/src/eu/kanade/tachiyomi/extension/pt/bladetoons/BladeToons.kt",
            "// base source\n",
        )
        self.write(
            "gradlew",
            "#!/usr/bin/env python3\n"
            "import pathlib, sys\n"
            "source = pathlib.Path('src/pt/bladetoons/src/eu/kanade/tachiyomi/extension/pt/bladetoons/BladeToons.kt').read_text()\n"
            "assert 'Nox functional code' in source, 'Nox code must be preserved in proof candidate'\n"
            "gradle = pathlib.Path('src/pt/bladetoons/build.gradle.kts').read_text()\n"
            "assert 'libVersion = \"1.6\"' in gradle, 'BladeToons metadata must be migrated to 1.6'\n"
            "multi = pathlib.Path('lib-multisrc/mangotheme/build.gradle.kts').read_text()\n"
            "assert 'libVersion = \"1.6\"' in multi, 'Mangotheme must be 1.6 in proof candidate'\n"
            "assert ':src:pt:bladetoons:assembleDebug' in sys.argv\n",
        )
        Path("gradlew").chmod(0o755)
        self.base = self.commit("base with mangotheme 1.4 and bladetoons 1.4")
        self.git("branch", "upstream", self.base)
        self.git("branch", "nox", self.base)

        # Nox customization on BladeToons
        self.git("checkout", "-q", "nox")
        self.write(
            f"{self.extension}/src/eu/kanade/tachiyomi/extension/pt/bladetoons/BladeToons.kt",
            "// Nox functional code: custom login and filters\n",
        )
        self.commit("Nox BladeToons customization")

    def _setup_upstream(self):
        self.git("checkout", "-q", "upstream")
        # Upstream updates mangotheme to 1.6, baseVersionCode 0
        self.write(
            f"{self.theme_unit}/build.gradle.kts",
            'libVersion = "1.6"\nbaseVersionCode = 0\n',
        )
        # Upstream updates BladeToons to 1.6, raw versionCode 0 -> pub 1.6.0 / 106000
        self.write(
            f"{self.extension}/build.gradle.kts",
            'libVersion = "1.6"\ntheme = "mangotheme"\nversionCode = 0\n',
        )
        self.write(
            f"{self.extension}/src/eu/kanade/tachiyomi/extension/pt/bladetoons/BladeToons.kt",
            "// Upstream source rewrite\n",
        )
        self.commit("upstream mangotheme 1.6 and bladetoons 1.6")
        self.git("checkout", "-q", "nox")

    def test_bladetoons_structural_migration_proven_atomic_apply(self):
        self._setup_upstream()

        base = self.git("merge-base", "HEAD", "upstream").strip()
        protected = sync_upstream.get_protected_nox_units(base, "upstream")
        self.assertIn(self.extension, protected)

        report, preflight_blocked = sync_upstream.preflight_multisrc(base, "upstream", protected)
        self.assertEqual(preflight_blocked, set())
        self.assertIn(self.theme, report)
        bt_row = next(r for r in report[self.theme] if r["unit"] == self.extension)
        self.assertTrue(bt_row["protected"])
        self.assertEqual(bt_row["local_libVersion"], "1.4")
        self.assertEqual(bt_row["upstream_libVersion"], "1.6")
        self.assertEqual(bt_row["multisrc_libVersion"], "1.6")
        self.assertTrue(bt_row["migration_required"])
        self.assertTrue(bt_row["migration_supported"])
        self.assertTrue(bt_row["source_divergent"])
        self.assertTrue(bt_row["unit_divergent"])

        # Preflight verification succeeds
        verified_blocked, verified_proven = sync_upstream.verify_migration_plan(report, "upstream")
        self.assertEqual(verified_blocked, set())
        self.assertIn(self.theme, verified_proven)
        self.assertEqual(verified_proven[self.theme]["units"], [self.extension])

        # Apply transaction
        units = sync_upstream.collect_units(sync_upstream.changed_entries(base, "upstream"))[0]
        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units(
                "upstream",
                units,
                set(),
                protected,
                [self.extension],
                set(),
                {},
                verified_proven,
            )

        # 1. Nox functional code preserved
        bt_code = Path(f"{self.extension}/src/eu/kanade/tachiyomi/extension/pt/bladetoons/BladeToons.kt").read_text()
        self.assertIn("Nox functional code: custom login and filters", bt_code)
        self.assertNotIn("Upstream source rewrite", bt_code)

        # 2. Structural metadata migrated to 1.6
        bt_gradle = Path(f"{self.extension}/build.gradle.kts").read_text()
        self.assertIn('libVersion = "1.6"', bt_gradle)
        self.assertIn('theme = "mangotheme"', bt_gradle)

        # 3. Mangotheme migrated to 1.6
        multi_gradle = Path(f"{self.theme_unit}/build.gradle.kts").read_text()
        self.assertIn('libVersion = "1.6"', multi_gradle)
        self.assertIn("baseVersionCode = 0", multi_gradle)

        # 4. Compatibility check passes
        self.assertEqual(sync_upstream.validate_multisrc_compatibility(), [])

        # 5. Versioning is monotonic and not arbitrarily bumped
        # Local before: 1.4.7 (code 104007)
        # Upstream new: 1.6.0 (code 106000)
        # Local after: raw 4 preserved, base 0 -> effective 4 -> 1.6.4 (code 106004)
        info = sync_upstream.effective_version_code(None, self.extension)
        self.assertIsNotNone(info)
        self.assertEqual(info.name, "1.6.4")
        self.assertEqual(info.android_code, 106004)
        self.assertGreater(info.android_code, 104007)
        self.assertGreater(info.android_code, 106000)

        # 6. Tree is clean and committed
        self.assertEqual(self.git("status", "--porcelain"), "")

    def test_bladetoons_structural_migration_failure_atomic_defer(self):
        self._setup_upstream()
        # Gradlew fails proof build
        self.write("gradlew", "#!/bin/sh\nexit 1\n")
        Path("gradlew").chmod(0o755)
        self.commit("make proof build fail")

        base = self.git("merge-base", "HEAD", "upstream").strip()
        protected = sync_upstream.get_protected_nox_units(base, "upstream")
        report, preflight_blocked = sync_upstream.preflight_multisrc(base, "upstream", protected)

        verified_blocked, verified_proven = sync_upstream.verify_migration_plan(report, "upstream")
        self.assertIn(self.theme, verified_blocked)
        self.assertNotIn(self.theme, verified_proven)

        blocked = preflight_blocked | verified_blocked
        deferred = sync_upstream.deferred_state(report, blocked, "upstream")
        units = sync_upstream.collect_units(sync_upstream.changed_entries(base, "upstream"))[0]

        with patch.object(sync_upstream, "validate_affected_builds"):
            sync_upstream.apply_units(
                "upstream",
                units,
                set(),
                protected,
                [],
                blocked,
                deferred,
                verified_proven,
            )

        # 1. Mangotheme stays 1.4
        multi_gradle = Path(f"{self.theme_unit}/build.gradle.kts").read_text()
        self.assertIn('libVersion = "1.4"', multi_gradle)
        self.assertIn("baseVersionCode = 3", multi_gradle)

        # 2. BladeToons stays 1.4
        bt_gradle = Path(f"{self.extension}/build.gradle.kts").read_text()
        self.assertIn('libVersion = "1.4"', bt_gradle)
        self.assertIn("versionCode = 4", bt_gradle)

        # 3. Nox functional code preserved
        bt_code = Path(f"{self.extension}/src/eu/kanade/tachiyomi/extension/pt/bladetoons/BladeToons.kt").read_text()
        self.assertIn("Nox functional code: custom login and filters", bt_code)

        # 4. Compatibility check passes (both are 1.4)
        self.assertEqual(sync_upstream.validate_multisrc_compatibility(), [])

        # 5. Deferred recorded
        deferred_saved = sync_upstream.load_deferred_migrations()
        self.assertIn(self.theme, deferred_saved)
        self.assertIn(self.extension, deferred_saved[self.theme]["units"])

        # 6. Tree is clean and committed
        self.assertEqual(self.git("status", "--porcelain"), "")


class BuildMatrixTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("build_matrices", SCRIPT.with_name("generate-build-matrices.py"))
        cls.matrix = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.matrix)

    def setUp(self):
        previous = Path.cwd()
        os.chdir(SCRIPT.resolve().parents[2])
        self.addCleanup(os.chdir, previous)

    def selected(self, path):
        with patch.object(self.matrix, "run_command", return_value=f"M\t{path}"):
            modules, deleted = self.matrix.get_module_list("HEAD")
        return set(modules), set(deleted)

    def test_a_sync_script_does_not_build_or_publish(self):
        self.assertEqual(self.selected(".github/scripts/sync-upstream.py"), (set(), set()))

    def test_b_sync_tests_do_not_build_or_publish(self):
        self.assertEqual(self.selected(".github/scripts/test_sync_upstream.py"), (set(), set()))

    def test_c_matrix_script_does_not_build_or_publish(self):
        self.assertEqual(self.selected(".github/scripts/generate-build-matrices.py"), (set(), set()))

    def test_d_core_still_builds_all_extensions(self):
        self.assertTrue(Path("core/build.gradle.kts").is_file())
        self.assertEqual(self.selected("core/build.gradle.kts"), tuple(map(set, self.matrix.get_all_modules())))

    def test_e_aurora_builds_exactly_four_dependents(self):
        names = {"mangasbrasuka", "mugiwarasoficial", "leitordemangas", "manganyx"}
        self.assertEqual(self.selected("lib-multisrc/aurora/build.gradle.kts"), (
            {f":src:pt:{name}" for name in names}, {f"pt.{name}" for name in names},
        ))

    def test_f_single_extension_stays_isolated(self):
        self.assertEqual(self.selected("src/pt/mangasbrasuka/build.gradle.kts"), (
            {":src:pt:mangasbrasuka"}, {"pt.mangasbrasuka"},
        ))


if __name__ == "__main__":
    unittest.main()
